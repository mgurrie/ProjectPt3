-- Jennifer and Mary Love
USE Pizzeria;

SELECT * FROM Pizzeria.customer;
SELECT * FROM Pizzeria.delivery;
SELECT * FROM Pizzeria.dinein;
SELECT * FROM Pizzeria.discount;
SELECT * FROM Pizzeria.discount_order;
SELECT * FROM Pizzeria.discount_pizza;
SELECT * FROM Pizzeria.`order`;
SELECT * FROM Pizzeria.pickup;
SELECT * FROM Pizzeria.pizza;
SELECT * FROM Pizzeria.pizza_base;
SELECT * FROM Pizzeria.topping;
SELECT * FROM Pizzeria.topping_pizza;