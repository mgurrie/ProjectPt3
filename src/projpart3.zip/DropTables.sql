-- Jennifer and Mary Love
USE Pizzeria;

DROP TABLE Pizzeria.delivery; 
DROP TABLE Pizzeria.dinein;
DROP TABLE Pizzeria.pickup;
DROP TABLE Pizzeria.discount_order;
DROP TABLE Pizzeria.discount_pizza;
DROP TABLE Pizzeria.topping_pizza;
DROP TABLE Pizzeria.discount;
DROP TABLE Pizzeria.pizza;
DROP TABLE Pizzeria.pizza_base;
DROP TABLE Pizzeria.topping;
DROP TABLE Pizzeria.`order`;
DROP TABLE Pizzeria.customer;

DROP SCHEMA Pizzeria;
